﻿insert into Verification.VerificationType values(N'قائمة الزامية')


 