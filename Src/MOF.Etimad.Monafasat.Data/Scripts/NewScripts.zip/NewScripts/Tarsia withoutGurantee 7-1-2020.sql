﻿ 
 update LookUps.NotificationOperationCode set EmailBodyTemplateAr = N'<p style="text-align:center">&nbsp;</p>
<p style="text-align:right">
	السادة / {0},<br>
	السلام عليكم ورحمة الله وبركاته ...
</p>
<p style="text-align:right">
	) إشارة إلى عرضكم رقم{1}) بتاريخ ({2}) المقدم :<br>
	للمنافسة رقم({3}) ({4}).<br><br>
	<br>
	نفيدكم بموافقة ({5}) على ترسية المنافسة عليكم:<br>
	بمبلغ اجمالى: ({6}) ريال.<br>
	بتاريخ: {7}.<br>
	<br>
	<br>
	(قرار الترسية لا يرتب أي التزام قانوني أو مالي على الجهة الحكومية إلا بعد توقيع العقد من جميع الأطراف)
	<br>
	فريق عمل منصة اعتماد
</p>',
EmailBodyTemplateEn =
 N'<p style="text-align:center">&nbsp;</p>
<p style="text-align:right">
	السادة / {0},<br>
	السلام عليكم ورحمة الله وبركاته ...
</p>
<p style="text-align:right">
	) إشارة إلى عرضكم رقم{1}) بتاريخ ({2}) المقدم :<br>
	للمنافسة رقم({3}) ({4}).<br><br>
	<br>
	نفيدكم بموافقة ({5}) على ترسية المنافسة عليكم:<br>
	بمبلغ اجمالى: ({6}) ريال.<br>
	بتاريخ: {7}.<br>
	<br>
	<br>
	(قرار الترسية لا يرتب أي التزام قانوني أو مالي على الجهة الحكومية إلا بعد توقيع العقد من جميع الأطراف)
	<br>
	فريق عمل منصة اعتماد
</p>'where NotificationOperationCodeId = 748  